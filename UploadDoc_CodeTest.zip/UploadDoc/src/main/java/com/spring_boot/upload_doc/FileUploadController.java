package com.spring_boot.upload_doc;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(value = "/file")
public class FileUploadController {

  @Autowired
  private FileUploadService fileUploadService;

  @RequestMapping(value = "/upload", method = RequestMethod.POST)
  public void uploadFile(@RequestParam(value = "file") MultipartFile file,
      @RequestParam(value = "userName") String userName, @RequestParam(value = "uploadDate") String date,
      @RequestParam(value = "fileName") String fileName) throws IOException {
    fileUploadService.uploadFile(file.getBytes(), userName, date, fileName);
  }

}
